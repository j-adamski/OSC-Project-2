#!/bin/sh
mkdir tasks
touch tasks/tasks.json
python3 t3.py --help
